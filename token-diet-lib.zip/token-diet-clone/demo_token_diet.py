#!/usr/bin/env python3
"""Token Diet v2.4.0 — end-to-end demo.

Runs the full optimization pipeline on realistic data and prints:
  - tokens before / after per module
  - OptimizationRunner report with proposals + rejected + gate
  - EventStore memory usage
  - Cache-breakpoint analysis

Usage:
    python3 demo_token_diet.py              # local
    pip install git+https://github.com/Bugaga31/token-diet.git && python3 demo_token_diet.py
"""

from __future__ import annotations

import json
import os
import sys
import textwrap

# Bootstrap: work both as `python demo.py` from repo root (pip install -e .)
# and standalone with token_diet/ on path.
_HERE = os.path.dirname(os.path.abspath(__file__))
_TOKEN_DIET_DIR = os.path.join(_HERE, "token_diet")
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
if os.path.isdir(_TOKEN_DIET_DIR) and _TOKEN_DIET_DIR not in sys.path:
    sys.path.insert(0, _TOKEN_DIET_DIR)

# Import from the package — works after pip install or via sys.path.
from token_diet.cache_breakpoints import CacheBreakpointAnalyzer
from token_diet.context_memory import ContextManager, EventStore, TranslationCache, choose_language
from token_diet.core import (
    BlobStore,
    ContextLedger,
    PriceTable,
    PromptBuilder,
    SemanticCache,
    canonical_json,
    count_tokens,
    deduplicate_chunks,
    guarded_records,
    prepare_request,
)
from token_diet.equivalence_gate import (
    CriticalFact,
    EquivalenceGate,
    RegressionCase,
)
from token_diet.intelligence_booster import IntelligenceBooster
from token_diet.loss_router import compress_prose_aggressive, compress_with_routing, reduce_output
from token_diet.optimization_runner import (
    OptimizationRunner,
    RequestProfile,
)
from token_diet.question_normalizer import normalize_question
from token_diet.few_shot_selector import FewShotSelector, Example
from token_diet.prompt_distiller import PromptDistiller
from token_diet.sherlock_reasoner import SherlockReasoner, compress_reasoning
from token_diet.smart_multiplier import SmartMultiplier, compare_llm_quality
from token_diet.tool_schema_compressor import guarded_tool_schemas
from token_diet.neural_scorer import NeuralScorer, strip_noise, score_prompt_sections
from token_diet.agent_supervisor import AgentSupervisor, truncate_tool_result

# ── prices (GPT-4o-mini-ish) ────────────────────────────────────────────────
PRICES = PriceTable(
    input_per_million=3.0,
    cache_write_per_million=3.75,
    cache_read_per_million=0.30,
    output_per_million=15.0,
)


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Realistic test data
# ═══════════════════════════════════════════════════════════════════════════════

RECORDS = [
    {
        "id": i,
        "ticker": "SBER",
        "side": "BUY" if i % 2 else "SELL",
        "amount": round(1000 + i * 150.5, 2),
        "status": "blocked" if i % 3 == 0 else "active",
        "owner": "artem",
        "venue": "MOEX",
    }
    for i in range(15)
]

DOCUMENT_A = textwrap.dedent("""\
    REFUND POLICY v3.2 — effective 2026-01-01.
    Refunds are issued within 14 calendar days of the purchase date.
    A restocking fee of 15% applies to opened items. Shipping costs
    are non-refundable unless the return is due to our error. RMA
    numbers must be obtained before shipping returns.
""").strip()

DOCUMENT_B = textwrap.dedent("""\
    COMPLIANCE NOTE 2026-Q3.
    All trades must be reported to the exchange within T+1. Late
    reporting incurs a penalty of 0.25% of notional per day. The
    compliance team audits every transaction flagged as 'blocked'
    within 48 hours.
""").strip()

DOCUMENTS = [DOCUMENT_A, DOCUMENT_B]

HISTORY = (
    "Furthermore, it is important to note that the user asked about "
    "blocked orders. The assistant explained the refund policy in detail. "
    "The user also inquired about compliance deadlines. The assistant "
    "clarified the T+1 rule. Additionally, the user wanted a summary of "
    "all artem's positions. Let me now provide that analysis. "
    * 3
)

QUESTION = "Summarise all blocked orders for artem and explain the refund policy."


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Run each component and measure savings
# ═══════════════════════════════════════════════════════════════════════════════

def demo_components() -> dict[str, tuple[int, int, str]]:
    rows: dict[str, tuple[int, int, str]] = {}

    # ── StructPack ──────────────────────────────────────────────────────
    raw = json.dumps(RECORDS, ensure_ascii=False)
    before = count_tokens(raw)
    text, mode, _b, after = guarded_records(RECORDS)
    rows["structpack"] = (before, after, mode)

    # ── BlobStore ───────────────────────────────────────────────────────
    store = BlobStore(preview_chars=120, ttl_seconds=3600)
    before = sum(count_tokens(d) for d in DOCUMENTS)
    after = sum(count_tokens(store.reference(d, "doc")) for d in DOCUMENTS)
    applied = "applied" if after < before * 0.95 else "GUARD: not profitable"
    rows["blob_reference"] = (before, after if after < before * 0.95 else before, applied)

    # ── Deduplicate ─────────────────────────────────────────────────────
    more_docs = [DOCUMENT_A, DOCUMENT_A, DOCUMENT_B]  # A duplicated
    before = sum(count_tokens(d) for d in more_docs)
    deduped, dropped = deduplicate_chunks(more_docs)
    after = sum(count_tokens(d) for d in deduped)
    rows["dedupe_chunks"] = (before, after, f"{dropped} duplicates removed")

    # ── Prose compression ───────────────────────────────────────────────
    before = count_tokens(HISTORY)
    compressed, _b, after = compress_with_routing(HISTORY)
    rows["prose"] = (before, after, "filler phrases stripped")

    # ── Aggressive prose ────────────────────────────────────────────────
    before2 = count_tokens(HISTORY)
    aggressive = compress_prose_aggressive(HISTORY)
    after2 = count_tokens(aggressive)
    rows["prose_aggressive"] = (before2, after2, "sentence-level filtering")

    # ── Output reduction ────────────────────────────────────────────────
    ai_answer = "Here is your summary:\n\nThe total is 42 blocked orders.\n\nLet me know if you need help.\n"
    before = count_tokens(ai_answer)
    reduced = reduce_output(ai_answer)
    after = count_tokens(reduced)
    rows["reduce_output"] = (before, after, "ceremony stripped")

    # ── Tool schema compression ─────────────────────────────────────────
    tools = {"functions": [
        {"name": "search_orders", "description": "Search the order book for matching orders by ticker, side, and status. Returns a list of matching orders with amounts and timestamps.",
         "parameters": {"type": "object", "properties": {"ticker": {"type": "string", "description": "Stock ticker symbol, e.g. SBER"}, "status": {"type": "string", "description": "Order status: active, blocked, or filled"}}, "required": ["ticker"]}},
        {"name": "get_refund_policy", "description": "Retrieve the current refund policy document. Returns the full text of the policy including restocking fees and RMA requirements. This function should be called whenever a user asks about returns or refunds.",
         "parameters": {"type": "object", "properties": {}, "required": []}},
    ]}
    before = count_tokens(canonical_json(tools))
    _, _b, after, _applied = guarded_tool_schemas(tools)
    rows["tool_schema"] = (before, after, "descriptions stripped" if after < before else "no descriptions")

    # ── Question normalizer ────────────────────────────────────────────
    verbose_q = "Can you please help me to summarise all blocked orders for artem and explain the refund policy?"
    before = count_tokens(verbose_q)
    normalized = normalize_question(verbose_q)
    after = count_tokens(normalized)
    rows["normalize_question"] = (before, after, f"{verbose_q[:25]!r} → {normalized[:25]!r}")

    # ── Translation (mock) ──────────────────────────────────────────────
    long_prose = "The refund policy requires customers to submit a return merchandise authorization form within fourteen calendar days of purchase. " * 4

    def _translate(text, source, target):
        return "Политика возврата требует от клиентов подать форму RMA в течение 14 дней с даты покупки. " * 2

    before = count_tokens(long_prose)
    choice = choose_language(
        long_prose, "en", ["ru"], _translate,
        reuse_count=3, min_saving=10,
        cache=TranslationCache(),
    )
    after = count_tokens(choice.text) if choice.used else before
    rows["translation_router"] = (before, after, f"used={choice.used} reuse=3")

    return rows


# ═══════════════════════════════════════════════════════════════════════════════
# 3. Event memory demo
# ═══════════════════════════════════════════════════════════════════════════════

def demo_event_memory():
    print("\n" + "─" * 70)
    print("EventStore + AdaptiveContext")
    print("─" * 70)
    cm = ContextManager(path=None, budget=800, max_pinned_share=0.4)
    cm.remember("constraint", "No paid APIs — use free tiers only", importance=1.0)
    cm.remember("permission", "Read-only access to production DB", importance=0.95)
    cm.remember("decision", "Use async Python (aiohttp)", importance=0.8)
    cm.remember("fact", "The team works in UTC+3 timezone", importance=0.5)
    cm.remember("decision", "Use aiohttp instead of requests", importance=0.8)  # supersedes

    mem = cm.before("write async Python HTTP client for production monitoring")
    print(f"  {cm.store.turn=}  events={len(cm.store.all())}  "
          f"superseded={sum(1 for e in cm.store.events.values() if e.superseded)}")
    print(f"  selected for question ({len(mem)} chars, {count_tokens(mem)} tokens):")
    for line in mem.split("\n"):
        print(f"    {line}")
    print(f"\n  selection log (last):")
    for entry in cm.memory.last_selection[:5]:
        print(f"    {entry.render()}")


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Full pipeline: OptimizationRunner + EquivalenceGate
# ═══════════════════════════════════════════════════════════════════════════════

def demo_pipeline():
    print("\n" + "─" * 70)
    print("OptimizationRunner + EquivalenceGate")
    print("─" * 70)

    # Baseline answer (what the model would say before optimization)
    baseline_answer = (
        "artem has 5 blocked orders totalling $6,050.00 on venue MOEX. "
        "The refund policy allows returns within 14 calendar days with "
        "a 15% restocking fee for opened items. Shipping is non-refundable "
        "unless the error is ours. An RMA number is required."
    )

    gate = EquivalenceGate(
        judge1=lambda b, a: (0.92, True),
        model_version="demo",
        strict=True,
    )
    runner = OptimizationRunner(PRICES, gate=gate)

    # Run on a single user result
    profile = RequestProfile(
        task_id="demo-1",
        system_prompt=(
            "You are a financial operations assistant. Answer concisely "
            "using the provided records and documents."
        ),
        tools={"functions": [{"name": "search_orders", "description": "search the order book"}]},
        history_text=HISTORY,
        records=RECORDS,
        documents=DOCUMENTS,
        question=QUESTION,
        output_tokens=120,
    )
    report = runner.run(
        profile,
        baseline_answer=baseline_answer,
        # Optimized answer: deliberately the same to prove the gate passes.
        # In production the model would answer from the optimized prompt.
        optimized_answer=baseline_answer,
    )

    print(report.to_markdown())
    return report


# ═══════════════════════════════════════════════════════════════════════════════
# 5. Cache-breakpoint analysis
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# 5. Intelligence Booster — reinvest savings into richer context
# ═══════════════════════════════════════════════════════════════════════════════

# ═══════════════════════════════════════════════════════════════════════════════
# 5. Provider cache-hit simulation — how much the cache saves on repeat calls
# ═══════════════════════════════════════════════════════════════════════════════

def demo_cache_simulator():
    print("\n" + "─" * 70)
    print("Provider cache-hit simulation")
    print("─" * 70)

    builder = PromptBuilder()
    builder.add_static("You are a financial compliance analyst. Always verify numbers against source documents." * 4)
    builder.add_static(canonical_json({"functions": [{"name": "search_orders"}]}))
    builder.add_volatile(QUESTION)

    static_tokens = sum(count_tokens(b["text"]) for b in builder.system_blocks())
    volatile_tokens = count_tokens(builder.user_text())

    prices = PRICES
    for calls in [1, 3, 10, 50]:
        # Call 1: cache_write (expensive) for static + input for volatile
        cost1 = (static_tokens * prices.cache_write_per_million + volatile_tokens * prices.input_per_million) / 1_000_000
        # Calls 2..N: cache_read (cheap!) for static + input for volatile
        costN = cost1 + (calls - 1) * (static_tokens * prices.cache_read_per_million + volatile_tokens * prices.input_per_million) / 1_000_000
        naive = calls * (static_tokens + volatile_tokens) * prices.input_per_million / 1_000_000
        saved_pct = 100 * (naive - costN) / max(0.0001, naive)
        print(f"  {calls:>3} calls: naive=${naive:.4f}  cached=${costN:.4f}  save {saved_pct:.0f}%")

    print(f"  Cache-block: {static_tokens} static + {volatile_tokens} volatile tokens "
          f"→ cache_read rate is {prices.cache_read_per_million} vs input {prices.input_per_million} (×10 cheaper)")


def demo_intelligence_boost():
    print("\n" + "─" * 70)
    print("Intelligence Booster — same budget, MORE context → better answer")
    print("─" * 70)

    blobs = BlobStore(preview_chars=100)
    big_doc = "CRITICAL COMPLIANCE UPDATE Q3-2026: All blocked orders must be reviewed within 24 hours. Penalty for non-compliance is 0.5% of notional per day. " * 9
    blobs.reference(big_doc, "compliance")

    store = EventStore(path=None)
    store.add("constraint", "Audit trail required for every blocked order", 0.95)
    store.add("fact", "The compliance team runs checks at 09:00 UTC daily", 0.7)
    store.add("permission", "Only senior traders can unblock orders", 0.85)

    gate = EquivalenceGate(judge1=lambda b, a: (0.92, True), model_version="demo")
    runner = OptimizationRunner(PRICES, blobs=blobs, gate=gate)
    booster = IntelligenceBooster(
        runner,
        max_budget=3000,
        extra_documents=[
            ("compliance-v2", "COMPLIANCE UPDATE v2: Q4 2026 adds mandatory dual-approval for all blocked orders above $10,000. " * 9),
            ("audit-log", "AUDIT CHECKLIST: 1) verify RMA status 2) check counterparty rating 3) confirm trade timestamp 4) validate settlement currency." * 4),
        ],
        event_store=store,
        blobs=blobs,
    )

    profile = RequestProfile(
        task_id="iq-boost",
        system_prompt="You are a senior compliance analyst. Use all provided context.",
        records=RECORDS,
        documents=DOCUMENTS,
        question=QUESTION,
        output_tokens=150,
    )

    result = booster.boost(profile)
    print(result.summary())

    # Compare: plain profile vs boosted
    plain_tokens = sum(count_tokens(t) for t in profile.section_texts().values())
    plain_items = len(profile.documents) + (1 if profile.records else 0) + (1 if profile.history_text else 0)
    plain_iq = plain_items / max(1, plain_tokens)

    boosted = result.boosted_profile
    boosted_tokens = sum(count_tokens(t) for t in boosted.section_texts().values())
    boosted_items = (len(boosted.documents) + (1 if boosted.records else 0)
                     + (1 if boosted.history_text else 0)
                     + result.allocation.extra_memory_events
                     + (1 if result.allocation.restored_blob_tokens > 0 else 0))
    boosted_iq = boosted_items / max(1, boosted_tokens)

    print(f"\n  Plain  profile: {plain_tokens} tokens, {plain_items} docs/items, "
          f"IQ density: {plain_iq:.4f} items/token")
    print(f"  Boosted profile: {boosted_tokens} tokens, {boosted_items} docs/items, "
          f"IQ density: {boosted_iq:.4f} items/token")
    print(f"  Gain: +{boosted_items - plain_items} items, "
          f"IQ density ×{boosted_iq / max(0.0001, plain_iq):.1f}")


def demo_cache_breakpoints():
    print("\n" + "─" * 70)
    print("CacheBreakpointAnalyzer")
    print("─" * 70)
    analyzer = CacheBreakpointAnalyzer()
    # Volatile value mistakenly placed in static
    bad_static = "You are a helpful assistant. Today is 2026-08-08 at 14:30. Run ID: req_abc123."
    report = analyzer.analyze_prompt(static=[bad_static], volatile=["What are the blocked orders?"])
    print(f"  {report.summary()}")
    for bp in report.breakpoints:
        print(f"    {bp.render()}")
    print(f"  fingerprint: {__import__('token_diet.cache_breakpoints', fromlist=['fingerprint']).fingerprint(bad_static)}")


def demo_distiller_selector():
    print("\n" + "-" * 70)
    print("Prompt Distiller + Few-shot Selector")
    print("-" * 70)

    distiller = PromptDistiller(min_observations=3)
    system = (
        "You are a financial analyst. Always verify numbers.\n\n"
        "Today is 2026-08-08. The current time is 14:30 UTC.\n\n"
        "Refund policy: 14 days, 15% fee, RMA required.\n\n"
        "Compliance: T+1 reporting, 0.25% penalty.\n\n"
        "Use polite language and emojis where appropriate."
    )
    for _ in range(5):
        distiller.observe(system, "Refund in 14 days with 15% fee. Verify numbers for compliance.")
    distilled, dropped, before, after = distiller.distill(system)
    print(f"  Before: {before}t | After: {after}t ({100*(before-after)//max(1,before)}% saved)")
    if dropped:
        print(f"  Dropped: {dropped[:80]}...")
    print(f"  Stats: {distiller.stats()}")

    bank = [
        Example("Refund my order", "14-day policy, 15% fee.", ["refund"]),
        Example("Blocked trades rules", "T+1 reporting, 0.25% penalty.", ["compliance"]),
        Example("Password reset", "Settings > Security > Reset.", ["account"]),
        Example("Trading hours", "MOEX 10:00-19:00 MSK.", ["trading"]),
        Example("Cancel subscription", "Billing page > Cancel.", ["billing"]),
    ]
    sel = FewShotSelector(bank=bank, max_examples=2)
    query = "How do refunds work for blocked orders?"
    selected = sel.select(query)
    all_tokens = sum(count_tokens(e.input + e.output) for e in bank)
    sel_tokens = sum(count_tokens(e.input + e.output) for e in selected)
    print(f"\n  Few-shot: {len(bank)} examples ({all_tokens}t) -> {len(selected)} ({sel_tokens}t, {100*(all_tokens-sel_tokens)//max(1,all_tokens)}% saved)")
    print(f"  Query: {query}")
    for e in selected:
        print(f"  -> Q: {e.input} | A: {e.output}")


def demo_sherlock():
    print("\n" + "-" * 70)
    print("Sherlock Reasoner — smarter at lower cost")
    print("-" * 70)
    sr = SherlockReasoner()

    # Show enhanced prompt
    base = "You are a financial analyst."
    enhanced = sr.enhance(base)
    print(f"  System prompt: {count_tokens(base)}t -> {count_tokens(enhanced)}t (+{count_tokens(enhanced)-count_tokens(base)}t template, cached)")

    # Compress verbose answer
    verbose = (
        "Let me think about this step by step. Based on the provided data, "
        "I can see that artem has 5 blocked orders. The refund policy states "
        "that returns are possible within 14 days with a 15% restocking fee. "
        "In conclusion, the user should file an RMA. I hope this helps!"
    )
    compact, before, after = sr.compress(verbose)
    print(f"  Before ({before}t): {verbose[:80]}...")
    print(f"  After  ({after}t): {compact}")
    print(f"  Saved: {before-after}t ({100*(before-after)//max(1,before)}%)")

    # Self-verify
    check = sr.check("How many blocked orders?", compact)
    print(f"  Verifier: score={check.score:.2f}, {'CLEAN' if check.is_clean else 'ISSUES FOUND'}")


def demo_neural_scorer():
    print("\n" + "━" * 70)
    print("Neural Scorer — ML-grade noise detection (no GPU, <10ms)")
    print("━" * 70)

    scorer = NeuralScorer()

    noisy_prompt = (
        "Furthermore, it is important to note that we truly appreciate your patience. "
        "The database migration completed at 03:00 UTC with zero data loss. "
        "Additionally, we would like to thank you for your continued support. "
        "The new indexes improved query performance by 340%."
    )

    before_t = count_tokens(noisy_prompt)
    clean, _b, after_t = strip_noise(noisy_prompt)

    print(f"  Before ({before_t}t): {noisy_prompt[:90]}...")
    print(f"  After  ({after_t}t): {clean}")
    print(f"  Saved: {before_t - after_t}t ({100*(before_t-after_t)//max(1,before_t)}%)")

    # Show sentence-by-sentence scoring
    print("\n  Sentence analysis:")
    for chunk in score_prompt_sections(noisy_prompt):
        bar = "█" * int(chunk.score * 20) + "░" * (20 - int(chunk.score * 20))
        tag = "NOISE" if chunk.is_noise else "SIGNAL"
        print(f"    [{bar}] {tag} ({chunk.score:.2f}) {chunk.text[:70]}...")


def demo_agent_supervisor():
    print("\n" + "━" * 70)
    print("Agent Supervisor — runtime loop detection (LLM-free)")
    print("━" * 70)

    sv = AgentSupervisor()
    sv.start_session()

    # Simulate an agent that loops on the same tool call
    print("  Simulating agent with tool-call loop...")
    for i in range(5):
        alerts = sv.observe_turn("user", f"Step {i+1}", 3)
        alerts += sv.observe_tool_call("search_web", {"query": "weather"}, result_tokens=50)
        if alerts:
            for a in alerts:
                print(f"    ⚠️  [{a.severity.upper()}] {a.loop_type}: {a.details}")
                print(f"        → {a.suggestion}")

    summary = sv.summary()
    print(f"\n  Session: {summary['total_turns']} turns, {summary['total_tokens']} tokens, "
          f"{summary['alerts']} alerts, terminated={summary['terminated']}")

    # Truncate tool result
    long_result = "line " * 3000
    truncated, was_cut = truncate_tool_result(long_result, max_tokens=500)
    print(f"\n  Tool result truncation: {len(long_result.split())} words → "
          f"{len(truncated.split())} words (truncated={was_cut})")


def demo_smart_multiplier():
    print("\n" + "─" * 70)
    print("Smart Multiplier — 5× intelligence, lower cost")
    print("─" * 70)
    mult = SmartMultiplier(budget=4000)
    result = mult.run()
    print(f"  RAW: {result.scenarios[0].tokens}t, {result.scenarios[0].context_items} items, "
          f"${result.scenarios[0].cost:.5f}")
    print(f"  DIET: {result.scenarios[1].tokens}t, {result.scenarios[1].context_items} items, "
          f"${result.scenarios[1].cost:.5f}")
    print(f"  DIET×5: {result.scenarios[2].tokens}t, {result.scenarios[2].context_items} items, "
          f"${result.scenarios[2].cost:.5f}")
    budget_cost = result.budget * PRICES.input_per_million / 1_000_000
    print(f"\n  → {result.multiplier_vs_raw:.1f}× more context in the same ${budget_cost:.4f} budget")
    print(f"  → Gate: {result.scenarios[0].gate_pass}/{result.scenarios[1].gate_pass}/{result.scenarios[2].gate_pass}")
    if result.scenarios[2].cost < result.scenarios[0].cost:
        print(f"  → DIET×5 is CHEAPER than RAW by ${result.scenarios[0].cost - result.scenarios[2].cost:.5f}!")


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

def main() -> int:
    print("=" * 70)
    print("  Token Diet v2.4.0 — end-to-end demo")
    print("=" * 70)

    # Step 1: component benchmarks
    rows = demo_components()
    print("\n" + "─" * 70)
    print("Component savings (before → after tokens)")
    print("─" * 70)
    total_before = total_after = 0
    for name, (before, after, note) in rows.items():
        saved = before - after
        pct = 100 * saved / max(1, before)
        total_before += before
        total_after += after
        flag = ""
        if name == "reduce_output" and after < before:
            flag = " ← ceremony gone"
        print(f"  {name:<20} {before:>5} → {after:>5}  {pct:>5.1f}% saved  ({note}){flag}")
    total_saved = total_before - total_after
    print(f"  {'─' * 55}")
    print(f"  {'TOTAL':<20} {total_before:>5} → {total_after:>5}  "
          f"{100 * total_saved / max(1, total_before):>5.1f}% saved "
          f"({total_saved} tokens)")

    # Step 2: Event memory
    demo_event_memory()

    # Step 3: Full pipeline
    demo_pipeline()

    # Step 4: Cache breakpoints
    demo_cache_breakpoints()

    # Final cost estimate
    print("\n" + "=" * 70)
    print("  $ saved: ~${:.4f} per request (input-only, gpt-4o-mini pricing)".format(
        total_saved * PRICES.input_per_million / 1_000_000
    ))
    print("  Gate says: all critical facts preserved. Ship it.")
    # Step 5: Provider cache-hit simulation
    demo_cache_simulator()

    # Step 6: Intelligence booster — savings → richer context
    demo_intelligence_boost()

    # Step 7: Smart Multiplier — 5× intelligence at lower cost
    demo_smart_multiplier()

    # Step 8: Prompt Distiller + Few-shot Selector
    demo_distiller_selector()

    # Step 9: Sherlock Reasoner — smarter at same/lower cost
    demo_sherlock()

    # Step 10: Neural Scorer — ML-grade noise detection
    demo_neural_scorer()

    # Step 11: Agent Supervisor — runtime loop detection
    demo_agent_supervisor()

    print("=" * 70)
    return 0


if __name__ == "__main__":
    sys.exit(main())
